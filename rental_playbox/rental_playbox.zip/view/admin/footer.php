<footer class="bg-dark text-white py-3 mt-5">
    <div class="container text-center">
        <p class="mb-0">&copy; Rental Playbox  Admin Panel</p>
    </div>
</footer>