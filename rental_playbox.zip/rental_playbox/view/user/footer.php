<footer class="bg-dark text-white py-4 mt-5">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <h5>Tentang Rental Playbox</h5>
                <p>Temukan keseruan gaming tanpa batas! Rental Playbox menyediakan PlayStation 4 
                    lengkap dengan koleksi game terbaik dalam berbagai paket fleksibel, siap menemani momen hiburan Anda.</p>
            </div>
            <div class="col-md-4">
                <h5>Kontak Kami</h5>
                <ul class="list-unstyled">
                    <li><i class="bi bi-geo-alt"></i> Jl. Gurun Laweh Nanggalo</li>
                    <li><i class="bi bi-telephone"></i> (021) 123-4567</li>
                    <li><i class="bi bi-envelope"></i> info@rentalplaybox.com</li>
                </ul>
            </div>
            <div class="col-md-4">
                <h5>Jam Operasional</h5>
                <ul class="list-unstyled">
                    <li>Buka 24 Non Stop</li>
                </ul>
            </div>
        </div>
        <hr>
        <div class="text-center">
            <p class="mb-0">&copy; Console.Playbox </p>
        </div>
    </div>
</footer>